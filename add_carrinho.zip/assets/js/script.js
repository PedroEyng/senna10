document.querySelector('#close-edit').onclick = () => {
    document.querySelector('.edit-form-container').style.display = 'none';
    window.location.href = 'estoque.php';
   };
